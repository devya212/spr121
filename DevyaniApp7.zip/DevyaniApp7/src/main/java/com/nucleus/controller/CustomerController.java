package com.nucleus.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.dao.ICustomerDao;
import com.nucleus.model.Customer;

@Controller
public class CustomerController {
	
	@Autowired
	ICustomerDao customerDao;
	
	@RequestMapping("/RegisterCustomer")	
	public ModelAndView request1(@ModelAttribute("customer2") Customer customer2)
	{
		//customer.setCustname("aaaa");
		return new ModelAndView("customerform");
	}
	@RequestMapping("/DeleteCustomer")	
	public ModelAndView request5(@ModelAttribute("customer2") Customer customer2)
	{
		//customer.setCustname("aaaa");
		return new ModelAndView("deleteform");
	}
	@RequestMapping("/UpdateCustomer")	
	public ModelAndView request6(@ModelAttribute("customer2") Customer customer2)
	{
		//customer.setCustname("aaaa");
		return new ModelAndView("updateform");
	}
	
	
	@RequestMapping("/saveCustomer")
	public ModelAndView request2(@ModelAttribute("customer2") @Valid Customer customer, BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("customerform");
		}
		customerDao.saveCustomer(customer);
		return new ModelAndView("result","cust",customer);
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView request3(@ModelAttribute("customer2") @Valid Customer customer, BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("deleteform");
		}
		customerDao.delete(customer);
		return new ModelAndView("result","cust",customer);
	}
	@RequestMapping("/updateCustomer")
	public ModelAndView request4(@ModelAttribute("customer2") @Valid Customer customer, BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("updateform");
		}
		customerDao.update(customer);
		return new ModelAndView("result","cust",customer);
	}
	@RequestMapping("/viewCustomer")
	public ModelAndView request7()
	{
		/*return new ModelAndView("result3");*/
		
		List<Customer> custo=customerDao.selectAll();
		return new ModelAndView("result3","cust",custo);
	}
}
