package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public interface ICustomerDao {
public void saveCustomer(Customer customer);
public void delete(Customer customer);
public void update(Customer customer);
public List<Customer> selectAll();
}
