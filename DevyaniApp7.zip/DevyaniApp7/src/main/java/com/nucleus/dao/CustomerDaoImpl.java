package com.nucleus.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.dao.mapper.CustomerRowMapper;
import com.nucleus.model.Customer;
@Repository
public class CustomerDaoImpl implements ICustomerDao 
{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public void saveCustomer(Customer customer) {
		Object obj[]={customer.getCustomerid(),customer.getCustname()};
		jdbcTemplate.update("insert into cust0 values(?,?)",obj);
	}

	@Override
	public void delete(Customer customer) {
		jdbcTemplate.update("delete from cust0 where cid=?",customer.getCustomerid());
		
	}
	@Override
	public void update(Customer customer) {
		jdbcTemplate.update("update cust0 set cname=? where cid=?",customer.getCustname(),customer.getCustomerid());
		
	}
	@Override
	 public List<Customer> selectAll() {
	      
	        return (List<Customer>) jdbcTemplate.query("select cid, cname from cust0",new CustomerRowMapper());
	    }

}
